import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import '../../../app/constants/app_constants.dart';
import '../../../app/services/api_client.dart';
import '../../../app/services/auth_service.dart';
import '../../../app/services/local_data_service.dart';

class DashboardController extends GetxController {
  final ApiClient _api = ApiClient.to;
  final LocalDataService _local = LocalDataService.to;
  final loading = true.obs;
  final isAdmin = false.obs;

  final RxMap adminData = RxMap();
  final RxMap cashierData = RxMap();

  @override
  void onInit() {
    super.onInit();
    isAdmin.value = AuthService.to.currentUser?.isAdmin ?? false;
    load();
  }

  Future<void> load() async {
    loading.value = true;
    if (AppConstants.localMode) {
      if (isAdmin.value) {
        adminData.value = await _local.getAdminDashboard();
      } else {
        final userId = AuthService.to.currentUser?.idUser ?? 0;
        cashierData.value = await _local.getCashierDashboard(userId);
      }
      loading.value = false;
      return;
    }
    final path = isAdmin.value ? '/dashboard/admin' : '/dashboard/cashier';
    final res = await _api.get(path, fromData: (d) => d);
    loading.value = false;
    if (res.success && res.data != null) {
      final map = res.data is Map ? res.data as Map : <String, dynamic>{};
      if (isAdmin.value) {
        adminData.value = map;
      } else {
        cashierData.value = map;
      }
    } else {
      EasyLoading.showError(res.message);
    }
  }
}
