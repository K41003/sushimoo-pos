import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../../app/constants/colors.dart';
import '../../../app/constants/dimensions.dart';
import '../../../shared/utils/responsive.dart';
import '../../../app/routes/app_routes.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_scaffold.dart';
import '../../../shared/widgets/glass_panel.dart';
import '../controllers/setting_controller.dart';

/// REPLACES `setting_page.dart` 1:1 — same class name `SettingPage`.
class SettingPage extends GetView<SettingController> {
  const SettingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Pengaturan',
      currentRoute: AppRoutes.setting,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(Responsive.padding(context)),
        child: Column(
          children: [
            GlassPanel(
              radius: AppDimensions.radiusLg,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(Icons.print_outlined, color: AppColors.ink, size: 20.sp),
                      SizedBox(width: 12.w),
                      const Text('Printer Thermal'),
                    ],
                  ),
                  Obx(() => AppButton(
                        label: controller.printerConnected.value ? 'Terhubung' : 'Hubungkan',
                        onPressed: controller.connectPrinter,
                        primary: !controller.printerConnected.value,
                        fullWidth: false,
                      )),
                ],
              ),
            ),
            SizedBox(height: 14.h),
            AppButton(
              label: 'Keluar',
              primary: false,
              icon: Icons.logout,
              onPressed: controller.logout,
            ),
          ],
        ),
      ),
    );
  }
}
